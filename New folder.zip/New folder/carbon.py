from uedge import *
import os

def set_h_gas(fluid_neuts: bool = True):
    """Apply neutral hydrogen settings"""
    # Atomic Physics
    com.istabon = 10  # 10=>Stotler tables
    bbb.isrecmon = 1  # =1 for recombination

    # Neutral gas properties
    com.ngsp = 1
    bbb.ineudif = 2  # pressure driven neutral diffusion
    bbb.ngbackg = 1.0e13  # 1.e15 # 1.e12 #          # background gas level (1/m**3)
    if fluid_neuts:
        bbb.isupgon[0] = 1
        bbb.isngon[0] = 0
        com.nhsp = 2
        bbb.ziin[com.nhsp - 1] = 0
        bbb.gcfacgx = 1.0  # sets plate convective gas flux
        bbb.gcfacgy = 1.0  # sets wall convective gas flux
    else:
        bbb.isupgon[0] = 0
        bbb.isngon[0] = 1
        com.nhsp = 1


def set_carbon_imps():
    """Apply carbon impurity settings"""
    # Impurities
    bbb.isimpon = 6
    com.ngsp = 2
    com.nzsp[0] = 6  # NUMBER OF IMPURITY SPECIES FOR CARBON

    # CARBON

    bbb.isngon[1] = 1  # turns on impurity gas
    bbb.n0g[1] = 1.0e17
    bbb.isupgon[1] = 0  # impurity gas is diffusive
    bbb.recycp[1] = 1.0e-10  # recycling of impurity species
    bbb.recycw[1] = 1.0e-10  # recycling at wall, do not set =0!
    bbb.ngbackg[1] = 1.0e10  # background density for impurity gas

    # Carbon ion species
    bbb.allocate()  # allocate space for source arrays,
    # and also ni and up for impurity species.
    bbb.minu[com.nhsp : com.nhsp + 6] = 12.0  # mass in AMU
    bbb.ziin[com.nhsp : com.nhsp + 6] = array(
        [1, 2, 3, 4, 5, 6]
    )  # iota(6)	# charge of each impurity species
    bbb.znuclin[0 : com.nhsp] = 1  # nuclear charge
    bbb.znuclin[com.nhsp : com.nhsp + 6] = 6  # nuclear charge of impurities
    bbb.nzbackg = 1.0e10  # background density for impurities
    bbb.n0[com.nhsp : com.nhsp + 6] = 1.0e17  # global density normalization
    bbb.inzb = 2  # parameter for implementing impurity floor
    bbb.isbohmms = 0  # Bohm BC at plates for impurities
    bbb.isnicore[com.nhsp : com.nhsp + 6] = 0  # =0 for core flux BC =curcore
    # =1 for fixed core density BC
    # =3 constant ni on core,
    #           total flux=curcore

    bbb.recycc[1] = 0  # no core recycling of carbon gas

    bbb.curcore[com.nhsp : com.nhsp + 6] = 0.0

    bbb.isnwcono[com.nhsp : com.nhsp + 6] = (
        3  # 1 - set to nwallo ; 3 - set to (1/n)dn/dy = 1/lyni
    )
    bbb.nwallo = 1.0e12
    bbb.isnwconi[com.nhsp : com.nhsp + 6] = 3
    bbb.nwimin[com.nhsp : com.nhsp + 6] = 1.0e7
    bbb.nwomin[com.nhsp : com.nhsp + 6] = 1.0e7

    bbb.rcxighg = 0.0  # force charge exchange small
    bbb.kelighi[bbb.iigsp - 1] = 5.0e-16  # sigma-v for elastic collisions
    bbb.kelighg[bbb.iigsp - 1] = 5.0e-16
    com.iscxfit = 2  # use reduced Maggi CX fits

    # Impurity data files
    bbb.ismctab = 2  # =1 use multi charge tables from INEL
    # =2 Use multi charge tables from Strahl
    com.nzdf = 1
    com.mcfilename = ["b2frates_C"]  # , "b2frates_Li_v4"]
    com.isrtndep = 1


def set_carbon_sputtering(fhaasz: float = 0):
    """Apply carbon sputtering settings

    :param fhaasz: Coefficient for chemical and physical sputtering. When fhaasz=1 usual Haasz model is used, but convergence is
    reached more easily by steadily increasing this value from 0, defaults to 0
    """
    # Sputtering
    bbb.isch_sput[1] = 7  # Haasz/Davis sputtering model
    bbb.isph_sput[1] = 3  # Haasz/Davis sputtering model
    bbb.t_wall = 300
    bbb.t_plat = 600
    bbb.crmb = bbb.minu[0]  # set mass of bombarding particles

    bbb.fchemylb = fhaasz
    bbb.fchemyrb = fhaasz
    bbb.fphysylb = fhaasz
    bbb.fphysyrb = fhaasz
    bbb.fchemygwi = fhaasz
    bbb.fchemygwo = fhaasz
