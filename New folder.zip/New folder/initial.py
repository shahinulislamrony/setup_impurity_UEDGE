# --- General Settings ---
bbb.isimpon = 6
bbb.isofric = 1                   # Use general bbb.friction force expression
bbb.cfparcur = 1.0                # Scale factor for bbb.fqp=parcurrent from fmombal
bbb.kye = 0.5                     # chi_e for radial electron energy diffusion
bbb.kyi = 0.5                     # chi_i for radial ion energy diffusion

# --- Species and Impurity Settings ---
com.nzsp[0] = 3
com.ngsp = 2
bbb.isngon[1] = 1
bbb.isupgon[1] = 0

# --- Recycling and Background ---
bbb.recycp[1] = 3e-3              # About the limit
bbb.recycw[1] = 0.01              # Recycle lithium
bbb.ngbackg[1] = 1e12
bbb.nzbackg = 1e10
bbb.inzb = 4                      # Exponent of bkg imp source

# --- Allocate and Set Impurity Properties ---
bbb.allocate()
bbb.minu[com.nhsp:com.nhsp+3] = 7.0
bbb.ziin[com.nhsp:com.nhsp+3] = array([1, 2, 3])
bbb.znuclin[0:com.nhsp] = 1
bbb.znuclin[com.nhsp:com.nhsp+3] = 3
bbb.n0[com.nhsp:com.nhsp+3] = 1e17
bbb.isnion[com.nhsp:com.nhsp+3] = 1
bbb.recycp[com.nhsp:com.nhsp+3] = 1e-10
bbb.recycw[com.nhsp:com.nhsp+3] = 1e-10
bbb.ngbackg[1] = 1e10

# --- Core and Wall Conditions ---
bbb.isnicore[com.nhsp:com.nhsp+3] = 0
bbb.isupcore[com.nhsp:com.nhsp+3] = 3
bbb.isnwcono[com.nhsp:com.nhsp+3] = 3
bbb.nwomin[com.nhsp:com.nhsp+3] = 1e13
bbb.nwimin[com.nhsp:com.nhsp+3] = 1e13

# --- Density and Population Initialization ---
bbb.nis[:,:,1] = bbb.ni[:,:,0] * 1e-4   # Li1+
bbb.nis[:,:,2] = bbb.ni[:,:,0] * 1e-4   # Li2+
bbb.nis[:,:,3] = bbb.ni[:,:,0] * 1e-4   # Li3+
bbb.ngs[:,:,1] = bbb.ng[:,:,0] * 1e-4

# --- Diffusion and Viscosity ---
bbb.difni[com.nhsp:com.nhsp+3] = 0.5
bbb.difni2[com.nhsp:com.nhsp+3] = 0.5
bbb.travis[com.nhsp:com.nhsp+3] = 1.0
bbb.parvis[com.nhsp:com.nhsp+3] = 1.0

# --- Rate Tables and Monte Carlo ---
bbb.ismctab = 2
com.nzdf = 1
com.mcfilename = "b2frates_Li_v4_mod3"
com.isrtndep = 1

# --- Sputtering and Boundary Conditions ---
bbb.isph_sput[1] = 1
bbb.isch_sput[1] = 1
bbb.crmb = bbb.minu[0]
bbb.fchemylb = 1e-5
bbb.fchemyrb = 1e-5
bbb.fphysylb = 0.35
bbb.fphysyrb = 0.35
bbb.fchemygwi = 1e-5
bbb.fchemygwo = 1e-5
bbb.isybdryog = 1

# --- Save to HDF5 File ---
savefile = "Li.hdf5"
hdf5_save(savefile)