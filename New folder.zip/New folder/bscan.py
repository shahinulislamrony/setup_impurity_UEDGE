b0_start = bbb.b0
print("************************")
print("***** Starting b0 is", b0_start)
print("************************")

b0_end = 1.0
b0_step = 5
bbb.issfon =1
bbb.ftol=1e-6

while bbb.b0 > b0_end:
    bbb.b0 = max(b0_end, bbb.b0 - b0_step)
    print("\n-----------------------------")
    print(f"🔽 Reduced b0 to: {bbb.b0:.2f}")

    bbb.ftol=1e-6; bbb.issfon = 1
    bbb.dtreal=1e-10; bbb.exmain()
    bbb.dtreal=1e-9; bbb.exmain()
        
    rundt(dtreal=1e-9)

    if bbb.iterm == 1:
        fname = f"tmp_b0_{bbb.b0:.3e}.h5"
        print("✅ Solution converged. Saving in file:", fname)
        hdf5_save(fname)
    else:
        print("⚠️ No convergence at b0 =", bbb.b0)

    
       
